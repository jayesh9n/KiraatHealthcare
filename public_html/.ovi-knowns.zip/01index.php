<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Your Ovipanel account is active!</title>
       <!--link rel="icon" type="image/png" href="./favicon.ico"-->

        <style>
            html {
                height: 80%;
            }
            body {
                text-align:left;
                height:100%;
                background: #F3F3F3;
                font-size: 62.5%;
                font-family: 'Lucida Grande', Verdana, Arial, Sans-Serif;
                margin-top:10px;
                margin-bottom:10px;
                margin-right:10px;
                margin-left:10px;
                padding:0px;
            }
            body,td,th {
                font-family: Verdana, Arial, Helvetica, sans-serif;
                font-size: 9pt;
                color: #333333;
            }
            h1,h2,h3,h4,h5,h6 {
                font-family: Geneva, Arial, Helvetica, sans-serif;
            }
            h1 {
                font-size: 28px;
                font-weight:bold;
                color: #336;
                text-shadow:3px 3px 5px #BBBBBB;
            }
            a:link,a:visited,a:hover,a:active {
                color: #336;
                text-decoration:none;
            }
            ol{
                color:#336;
                font-size: 24px;
                font-weight:bold;
                text-shadow:3px 3px 5px #BBBBBB;
            }
            ol p{
                color:#CCCCCC;
                font: normal 12pt Verdana, Arial, Helvetica, sans-serif;
                color: #333333;
            }
            .content{
                background:#F1F4F6;
                background: #F1F4F6 url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAA6CAYAAAB4Q5OdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAABKklEQVR42mL8DwQMaAAggJgYsACAAMIqCBBAWAUBAgirIEAAYRUECCAWLJYzAAQQy38sKgECCKt2gADCKggQQFgFAQIIq0UAAYRVJUAAYRUECCCsggABhFUQIIBYsNjDABBAWFUCBBALAwOmUoAAwqoSIICwCgIEEFaLAAIIq0qAAMIqCBBAWAMEIICwqgQIIKyCAAGEVRAggLAKAgQQVkGAAMIqCBBAWJ0EEEBYVQIEEFZBgADCmmwAAgirSoAAwioIEEBYbQcIIKwqAQIIqyBAAGEVBAggrIIAAYQ14gACCKtKgADC6iSAAMKqEiCAsAoCBBBWQYAAwioIEEBYkyJAAGFVCRBAWAUBAgirjwACCGt0AAQQVu0AAYRVECCAsAoCBBDWAAEIMAAoCSZuy+v+UQAAAABJRU5ErkJggg==') repeat-x top;
                border:solid 1px #DFDFDF;
                margin: 10px 0;
                padding: 0 20px 10px;
                -moz-border-radius: 10px;
                border-radius: 10px;
                min-height: 90%;
            }
            .header_logo {
                display:block;
                max-width:263px;
                max-height:70px;
            }
            .header_logo img {
              max-width:345px;
             max-height:77px;
            }
            .poweredbox {
                font-family: Geneva, Arial, Helvetica, sans-serif;
                color:#333333;
                padding-left: 15px;
            }
        </style>
    </head>
    <body>
        <a class="header_logo" href="https://ovipanel.in/" target="_blank">
            <img src="ovi-logo.png"
                alt="OVIPanel - The open-source web hosting control panel" border="0"></a>
        <div class="content">
            <h1>Your hosting space is ready... </h1>
            <p>Your web hosting space is now active and ready to be used.</p>
            <p><b>To get started:</b>
                <ol>
                    <li><p>Login to your OVIPanel</p></li>
                    <li><p>Create an FTP account</p></li>
                    <li><p>Replace or delete this file (index.php)</p></li>
                </ol>
            </p>
            <p>Thank you for using OVIPanel to manage your hosting!</p>
            <p><b>For more information and help using OVIPanel please </b> <a href="https://ovipanel.in/tutorials" target="_blank">Click</a> here.</p>
            <p>Kind regards,<br>
                Your hosting company.</p>
        </div>
    </body>
</html>
